import './App.css';
import Home from './components/Home';


const App =()=>{


  return(

    <div className="App-body">
      <Home/>
  </div>
  )
}

export default App;
